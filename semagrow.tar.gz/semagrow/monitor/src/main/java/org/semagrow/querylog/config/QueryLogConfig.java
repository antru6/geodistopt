package org.semagrow.querylog.config;

/**
 * Created by kzam on 5/18/15.
 */
public interface QueryLogConfig {


}
