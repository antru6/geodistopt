/**
 * Semagrow Automated Rigorous Tester
 * 
 * <p>
 * Logging facility that extends the Logback framework to allow structured
 * information about the processing of AST expressions to be logged.
 * </p> 
 *  
 * @author Stasinos Konstantopoulos
 */

package org.semagrow.art;
