To compile a new version of frontend scripts you should manually:

1. ensure that nodejs/npm is installed in your machine
2. cd on this directory
3. execute 'npm install' to download required dependencies
4. execute 'gulp'. This command will also copy the end result to the appropriate location.
